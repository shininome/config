sketchybar --add alias "BusyCal Menu,Item-0" right \
	--set "BusyCal Menu,Item-0" update_freg=60
# --set click_script="osascript -e 'tell application \"BusyCal\" to activate'"

sketchybar --add alias "QWeather,Item-0" right \
	--set "QWeather,Item-0" update_freg=60
