# Load global styles, colors and icons
source "$CONFIG_DIR/globalstyles.sh"

wechat=(
	"${notification_defaults[@]}"
	icon=󰘑
	icon.font.size=20
	background.color=$(getcolor green)
	update_freq=10
	script="$PLUGIN_DIR/app_status.sh"
	click_script="open -a WeChat"
)

sketchybar --add item wechat right \
	--set wechat "${wechat[@]}"
