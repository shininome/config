# Load global styles, colors and icons
source "$CONFIG_DIR/globalstyles.sh"

spark=(
	"${notification_defaults[@]}"
	icon=􀍕
	background.color=$(getcolor blue)
	update_freq=10
	script="$PLUGIN_DIR/app_status.sh"
	click_script="open -a Spark"
)

sketchybar --add item spark right \
	--set spark "${spark[@]}"
