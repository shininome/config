# Load global styles, colors and icons
source "$CONFIG_DIR/globalstyles.sh"

qq=(
	"${notification_defaults[@]}"
	icon=󰘅
	background.color=$(getcolor green)
	icon.font.size=15
	update_freq=10
	script="$PLUGIN_DIR/app_status.sh"
	click_script="open -a qq"
)

sketchybar --add item qq right \
	--set qq "${qq[@]}"
